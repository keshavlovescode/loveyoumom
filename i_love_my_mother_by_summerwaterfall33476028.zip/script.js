document.addEventListener('DOMContentLoaded', () => {
  const toggleButton = document.getElementById('toggleButton');

  toggleButton.addEventListener('click', () => {
    alert("Sending a virtual hug to the best Mom in the world! ❤️");
  });
});